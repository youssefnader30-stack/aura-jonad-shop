# n8n AI Automation Starter Kit

This starter kit contains seven production-ready n8n workflow templates. Each workflow has:

- A manual test trigger
- Simulated input
- Validation and processing logic
- A dry-run branch that runs without external services
- A production output branch with placeholder credentials
- An error handling branch
- Sticky notes inside the workflow explaining the steps

## Files

- `workflow_1.json` - Lead Capture + Auto Follow-Up
- `workflow_2.json` - 3-Touch Email Sequence
- `workflow_3.json` - Invoice Generator
- `workflow_4.json` - Support Triage
- `workflow_5.json` - Weekly Report Builder
- `workflow_6.json` - Content Repurposer
- `workflow_7.json` - Competitive Scraper

## Workflows

### 1. Lead Capture + Auto Follow-Up

Captures a form lead, scores it, prepares CRM data, and drafts the first follow-up email.

Required APIs or services:
- Lead form or Webhook trigger
- CRM API such as HubSpot or Pipedrive
- Email provider or SMTP

### 2. 3-Touch Email Sequence

Builds a three-touch outreach plan with day offsets and sends the first touch when dryRun is disabled.

Required APIs or services:
- Email provider or SMTP
- CRM/contact source
- Optional delay/scheduling logic in n8n

### 3. Invoice Generator

Builds draft invoice data from structured line items and hands it to an accounting API.

Required APIs or services:
- Accounting API such as QuickBooks, Xero, or Stripe Invoicing
- Project/work-log source

### 4. Support Triage

Routes support tickets by category and priority with a concise suggested response.

Required APIs or services:
- Helpdesk API such as Zendesk, Intercom, Freshdesk, or Help Scout
- Optional Slack alert webhook

### 5. Weekly Report Builder

Creates a weekly report summary from KPI inputs and publishes it to a reporting endpoint.

Required APIs or services:
- KPI source such as Google Sheets, database, or analytics API
- Slack or email publishing endpoint

### 6. Content Repurposer

Repurposes one source text into social, email, thread, and caption drafts.

Required APIs or services:
- Content source such as Notion, Google Docs, or CMS
- Scheduling API such as Buffer, Hootsuite, or a CMS endpoint

### 7. Competitive Scraper

Builds a competitor monitoring payload for headline, pricing, offer, and case-study changes.

Required APIs or services:
- Scraping or browser API with permission to monitor target sites
- Slack/email alert endpoint


## Setup Steps

1. Import each `workflow_*.json` file into n8n.
2. Open the workflow and run the manual trigger. The default `dryRun: true` path should complete without external credentials.
3. Replace placeholder credentials:
   - `PLACEHOLDER_HTTP_HEADER_AUTH` for HTTP API calls.
   - `PLACEHOLDER_SMTP` for email sending.
4. Replace `https://api.example-*.com` and placeholder webhook URLs with your real production endpoints.
5. Set `dryRun` to `false` only after credentials and endpoints are configured.
6. Swap the manual trigger for your real trigger when ready, such as Webhook, Schedule Trigger, CRM trigger, helpdesk trigger, or form trigger.
7. Test with one safe record before activating the workflow.

## Credential Notes

No real API keys are included. Credentials are intentionally named placeholders so the workflows can be imported safely and wired to your own n8n credential records.

## Production Hardening Checklist

- Add rate limits for high-volume triggers.
- Add duplicate checks before creating CRM contacts, invoices, or tickets.
- Keep human approval before sending invoices, refunds, legal language, or customer promises.
- Log production errors to Slack, email, or your monitoring tool.
- Review generated AI text before enabling fully automatic sending.
